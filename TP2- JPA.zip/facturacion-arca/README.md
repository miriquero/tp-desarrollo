# TP Grupal – ORM / JPA / Hibernate – FacturaArca

Proyecto Maven que resuelve la consigna: mapeo objeto-relacional con JPA/Hibernate
sobre el modelo de dominio de facturación, con persistencia en cascada.

## Estructura

```
facturacion-arca/
├── pom.xml
└── src/main/
    ├── java/com/facturacion/
    │   ├── Main.java
    │   └── model/
    │       ├── EntityId.java              (@MappedSuperclass)
    │       ├── AuditoriaApp.java          (@MappedSuperclass)
    │       ├── Usuario.java
    │       ├── PuntoVenta.java
    │       ├── TipoMoneda.java
    │       ├── Rubro.java
    │       ├── Marca.java
    │       ├── Articulo.java
    │       ├── ListaPrecio.java
    │       ├── ListaPrecioArticulo.java
    │       ├── FacturaVenta.java
    │       ├── FacturaVentaDetalle.java
    │       ├── Contacto.java
    │       ├── Domicilio.java
    │       ├── CondicionIva.java
    │       └── Cliente.java
    └── resources/META-INF/
        └── persistence.xml
```

## 1. Anotaciones JPA

- `EntityId`: `@MappedSuperclass` con `id` anotado `@Id` + `@GeneratedValue(strategy = GenerationType.IDENTITY)`.
- `AuditoriaApp`: `@MappedSuperclass`, extiende `EntityId`. `fechaAlta` y `fechaModificacion`
  son `@Column(nullable = false)` con `@Temporal(TemporalType.TIMESTAMP)`. Las tres
  relaciones a `Usuario` son `@ManyToOne` (`usuarioCarga` y `usuarioModificacion` con
  `@JoinColumn(nullable = false)`, `usuarioBaja` opcional).
- Cada clase concreta lleva `@Entity` + `@Table(name = "...")`.
- Todos los campos marcados como obligatorios en el enunciado llevan `@Column(nullable = false)`.
- Asociaciones:
  - `@ManyToOne`: `AuditoriaApp -> Usuario`, `FacturaVenta -> PuntoVenta`,
    `FacturaVentaDetalle -> FacturaVenta / ListaPrecioArticulo`,
    `ListaPrecioArticulo -> ListaPrecio / Articulo`, `Articulo -> Rubro / Marca`.
  - `@OneToMany`: `FacturaVenta -> FacturaVentaDetalle`, con
    `mappedBy = "factura"` y `cascade = CascadeType.ALL`.
  - `@OneToOne`: `Cliente -> Contacto` y `Cliente -> Domicilio` (con cascada ALL
    para que el alta del cliente persista también su contacto y domicilio).

## 2. persistence.xml

Ubicado en `src/main/resources/META-INF/persistence.xml`. Define la unidad
`FacturacionPU` con el proveedor `org.hibernate.jpa.HibernatePersistenceProvider`,
las propiedades JDBC estándar (`javax.persistence.jdbc.driver/url/user/password`)
apuntando a MySQL, y las propiedades de Hibernate `show_sql`, `format_sql` y
`hbm2ddl.auto=update`.

**Antes de ejecutar**, editar en `persistence.xml`:
- `javax.persistence.jdbc.url` (nombre de la base de datos)
- `javax.persistence.jdbc.user` / `password` (credenciales reales de tu MySQL)

Si preferís PostgreSQL, dentro del `persistence.xml` está comentado el bloque
equivalente de propiedades; solo hay que reemplazar las 4 propiedades JDBC y
cambiar la dependencia del `pom.xml` de `mysql-connector-java` a `org.postgresql:postgresql`.

## 3. Main.java – Persistencia en cascada

`Main` crea el `EntityManagerFactory` con `Persistence.createEntityManagerFactory("FacturacionPU")`,
abre una transacción, instancia los datos maestros (`Usuario`, `PuntoVenta`, `Rubro`,
`Marca`, `Articulo`, `ListaPrecio`, `ListaPrecioArticulo`) y los persiste individualmente
(no participan de la cascada de `FacturaVenta`).

Luego arma la cabecera `FacturaVenta`, le agrega un `FacturaVentaDetalle` mediante el
método helper `facturaVenta.agregarDetalle(detalle)` (que setea la relación bidireccional
`detalle.setFactura(facturaVenta)`), y llama **una sola vez** a:

```java
em.persist(facturaVenta);
```

Gracias a `@OneToMany(mappedBy = "factura", cascade = CascadeType.ALL)`, Hibernate
inserta automáticamente tanto la fila de `factura_venta` como la(s) de
`factura_venta_detalle`. Finalmente hace `commit()` y cierra `EntityManager` y
`EntityManagerFactory` en el bloque `finally`.

## Cómo ejecutarlo

1. Tener MySQL corriendo (o ajustar `persistence.xml` para PostgreSQL).
2. Ajustar usuario/contraseña/URL en `persistence.xml`.
3. Desde la carpeta del proyecto:

```bash
mvn compile exec:java
```

(Con `hibernate.hbm2ddl.auto=update`, Hibernate crea/actualiza las tablas solo.)

## Notas / posibles ajustes según tu enunciado exacto

- Usé `javax.persistence.*` (Hibernate 5.6) para que coincidan los nombres de
  propiedad del enunciado (`javax.persistence.jdbc.driver`, etc.). Si tu cátedra
  usa Jakarta EE 9+/Hibernate 6, avisame y te paso la versión con `jakarta.persistence.*`.
- Los getters/setters están completos en todas las entidades para poder instanciar
  y probar el `Main` tal cual.
- Agregué un método `agregarDetalle(...)` en `FacturaVenta` solo como helper para
  mantener consistente la relación bidireccional; no es un requisito del enunciado
  pero es buena práctica y evita el típico bug de "olvidé setear el lado dueño".
